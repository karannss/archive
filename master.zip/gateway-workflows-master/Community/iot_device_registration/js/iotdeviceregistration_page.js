// Copyright 2020 BlueCat Networks. All rights reserved.
$(document).ready(function() 
{
    $("#file").prop("disabled", false);
    $("#submit").prop("disabled", false);
});
