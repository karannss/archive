# Copyright 2020 BlueCat Networks. All rights reserved.
# -*- coding: utf-8 -*-

type = 'api'
sub_pages = [
    {
        'name'        : 'manage_dhcp',
        'title'       : 'manage_dhcp',
        'endpoint'    : 'manage_dhcp/endpoint',
        'description' : 'manage_dhcp'
    },
]
