# Copyright 2018 BlueCat Networks. All rights reserved.
# -*- coding: utf-8 -*-

type = 'ui'
sub_pages = [
    {
        'name'        : 'SubnetStatus_page',
        'title'       : 'Subnet Status',
        'endpoint'    : 'SubnetStatus/SubnetStatus_endpoint',
        'description' : 'SubnetStatus'
    },
]
