// Copyright 2020 BlueCat Networks. All rights reserved.
$(document).ready(function() {

});

function clearForm() {
    document.getElementById("add_next_available_dual_stack_host_page_form").reset();
}