# Copyright 2020 BlueCat Networks. All rights reserved.
# -*- coding: utf-8 -*-

type = 'ui'
sub_pages = [
    {
        'name'        : 'cmdb_configuration_page',
        'title'       : u'CMDB Configuration',
        'endpoint'    : 'cmdb_configuration/cmdb_configuration_endpoint',
        'description' : u'cmdb_configuration'
    },
]
