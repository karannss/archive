# Copyright 2020 BlueCat Networks. All rights reserved.
# -*- coding: utf-8 -*-

type = 'ui'
sub_pages = [
    {
        'name'        : 'cmdb_switches_page',
        'title'       : u'CMDB Switches',
        'endpoint'    : 'cmdb_switches/cmdb_switches_endpoint',
        'description' : u'cmdb_switches'
    },
]
