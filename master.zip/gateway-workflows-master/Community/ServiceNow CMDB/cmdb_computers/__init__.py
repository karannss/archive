# Copyright 2020 BlueCat Networks. All rights reserved.
# -*- coding: utf-8 -*-

type = 'ui'
sub_pages = [
    {
        'name'        : 'cmdb_computers_page',
        'title'       : u'CMDB Computers',
        'endpoint'    : 'cmdb_computers/cmdb_computers_endpoint',
        'description' : u'cmdb_computers'
    },
]
