# Copyright 2020 BlueCat Networks. All rights reserved.
# -*- coding: utf-8 -*-

type = 'ui'
sub_pages = [
    {
        'name'        : 'acl_inventory_page',
        'title'       : u'ACL Inventory',
        'endpoint'    : 'acl_inventory/acl_inventory_endpoint',
        'description' : u'acl_inventory'
    },
]
