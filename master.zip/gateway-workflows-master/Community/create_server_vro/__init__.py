# Copyright 2020 BlueCat Networks. All rights reserved.
# -*- coding: utf-8 -*-

type = 'ui'
sub_pages = [
    {
        'name'        : 'create_server_vro_page',
        'title'       : u'Create Server vRO',
        'endpoint'    : 'create_server_vro/create_server_vro_endpoint',
        'description' : u'create_server_vro'
    },
]
