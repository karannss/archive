# Copyright 2018 BlueCat Networks. All rights reserved.
# -*- coding: utf-8 -*-

type = 'api'
sub_pages = [
    {
        'name'        : 'create_a_record_page',
        'title'       : u'create_a_record',
        'endpoint'    : 'create_a_record/create_a_record_endpoint',
        'description' : u'create_a_record'
    },
]
