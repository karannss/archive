# Copyright 2020 BlueCat Networks. All rights reserved.
# -*- coding: utf-8 -*-

type = 'ui'
sub_pages = [
    {
        'name'        : 'manage_service_requests_page',
        'title'       : 'Manage',
        'endpoint'    : 'manage_service_requests/manage_service_requests_endpoint',
        'description' : 'manage_service_requests'
    },
]
