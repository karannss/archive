servicenow_url = 'https://service-now.com/api/now/table/change_request'
servicenow_username = ''
servicenow_secret_file = 'workflows/Service Requests/configure_service_requests/.secret'
