# Copyright 2020 BlueCat Networks. All rights reserved.
# -*- coding: utf-8 -*-

type = 'ui'
sub_pages = [
    {
        'name'        : 'add_mac_address_page',
        'title'       : u'Add MAC Address',
        'endpoint'    : 'add_mac_address/add_mac_address_endpoint',
        'description' : u'add_mac_address'
    },
]
