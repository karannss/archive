# Copyright 2020 BlueCat Networks. All rights reserved.
# -*- coding: utf-8 -*-

type = 'ui'
sub_pages = [
    {
        'name'        : 'dump_data_page',
        'title'       : u'Dump Records',
        'endpoint'    : 'dump_data/dump_data_endpoint',
        'description' : u'dump_data'
    },
]
