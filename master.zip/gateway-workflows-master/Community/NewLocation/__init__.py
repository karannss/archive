# Copyright 2020 BlueCat Networks. All rights reserved.
# -*- coding: utf-8 -*-

type = 'ui'
sub_pages = [
    {
        'name'        : 'NewLocation_page',
        'title'       : 'New Location',
        'endpoint'    : 'NewLocation/NewLocation_endpoint',
        'description' : 'NewLocation'
    },
]
